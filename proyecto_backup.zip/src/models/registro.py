class Registro:
    def __init__(self, nombre_jugador: str, puntaje: int, laberinto: str):
        self.nombre_jugador = nombre_jugador
        self.puntaje = puntaje
        self.laberinto = laberinto
