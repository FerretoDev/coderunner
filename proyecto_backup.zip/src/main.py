from game.juego import Juego

# from Prototipo3.juego import Juego


def main():
    juego = Juego()
    juego.iniciar()


if __name__ == "__main__":
    main()
