from .interfaz import (
    MenuPrincipal,
    PantallaAdministracion,
    PantallaIniciarJuego,
    PantallaSalonFama,
)
