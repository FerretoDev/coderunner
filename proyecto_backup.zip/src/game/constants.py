# Configuración de la ventana del juego

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TITLE = "Mi Juego con Pygame"
FPS = 60

# Colores (R, G, B)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
